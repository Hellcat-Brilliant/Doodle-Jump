import pygame


class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.gravity = 0
        self.imagel1 = pygame.image.load(r"assets/images/left_1.png")  # согнутые
        self.imagel2 = pygame.image.load(r"assets/images/left.png")
        self.imager1 = pygame.transform.flip(self.imagel1, True, False)
        self.imager2 = pygame.transform.flip(self.imagel2, True, False)
        self.list1 = [self.imagel1, self.imager1]
        self.list2 = [self.imagel2, self.imager2]
        self.image = self.imagel1
        self.rect = self.image.get_rect()
        surface = pygame.display.get_surface()
        self.x = 0
        self.rect.center = surface.get_rect().center

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self, offset):
        self.gravity -= 1
        self.rect.y -= self.gravity
        self.pack = 0
        self.rect.y += offset
        key = pygame.key.get_pressed()
        surface = pygame.display.get_surface()
        if self.rect.right < surface.get_rect().left:
            self.rect.left = surface.get_rect().right
        if self.rect.left > surface.get_rect().right:
            self.rect.right = surface.get_rect().left
        if key[pygame.K_LEFT] or key[pygame.K_a]:
            self.x = 0
            self.rect.x -= 10
        if key[pygame.K_RIGHT] or key[pygame.K_d]:
            self.x = 1
            self.rect.x += 10
        if self.gravity > 0 and self.pack != self.list2:
            self.pack = self.list1
            self.image = self.pack[self.x]
        else:
            self.pack = self.list2
            self.image = self.pack[self.x]
import pygame


class GreenPlatform(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__()
        self.image = pygame.image.load(r"assets/images/green.png")
        self.rect = self.image.get_rect()
        self.rect.center = coords

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self, offset):
        surface = pygame.display.get_surface()
        if self.rect.top >= surface.get_rect().bottom:
            self.kill()
        self.rect.y += offset


class RedPlatform(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__()
        self.image1 = pygame.image.load(r"assets/images/red.png")
        self.image2 = pygame.image.load(r"assets/images/red_1.png")
        self.image = self.image1
        self.rect = self.image.get_rect()
        self.rect.center = coords

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self, offset):
        surface = pygame.display.get_surface()
        if self.rect.top >= surface.get_rect().bottom:
            self.kill()
        self.rect.y += offset


class BluePlatform(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__()
        self.image = pygame.image.load(r"assets/images/blue.png")
        self.rect = self.image.get_rect()
        self.x = -5
        self.rect.center = coords

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self, offset):
        surface = pygame.display.get_surface()
        if self.rect.left <= surface.get_rect().left:
            self.x = 5
        elif self.rect.right >= surface.get_rect().right:
            self.x = -5
        surface = pygame.display.get_surface()
        self.rect.x += self.x
        if self.rect.top >= surface.get_rect().bottom:
            self.kill()
        self.rect.y += offset
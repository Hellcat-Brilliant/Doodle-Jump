import pygame

class Spring(pygame.sprite.Sprite):
    def __init__(self, coords):
        super().__init__()
        self.image1 = pygame.image.load(r"assets/images/spring.png")
        self.image2 = pygame.image.load(r"assets/images/spring_1.png")
        self.image = self.image1
        self.rect = self.image.get_rect()
        self.rect.bottomleft = coords[0], coords[1] + 5

    def draw(self, surface):
        surface.blit(self.image, self.rect)

    def update(self, offset):
        surface = pygame.display.get_surface()
        if self.rect.top >= surface.get_rect().bottom:
            self.kill()
        self.rect.y += offset